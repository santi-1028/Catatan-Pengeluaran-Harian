package com.example.catatanpengeluaran;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

public class DatabaseHelper extends SQLiteOpenHelper {

    private static final String DATABASE_NAME = "CatatanPengeluaran.db";
    private static final int DATABASE_VERSION = 1;

    private static final String TABLE_NAME = "transaksi";

    private static final String COLUMN_ID = "id";
    private static final String COLUMN_JENIS = "jenis";
    private static final String COLUMN_NOMINAL = "nominal";

    public DatabaseHelper(Context context) {
        super(context, DATABASE_NAME, null, DATABASE_VERSION);
    }

    @Override
    public void onCreate(SQLiteDatabase db) {

        String query = "CREATE TABLE " + TABLE_NAME + " (" +
                COLUMN_ID + " INTEGER PRIMARY KEY AUTOINCREMENT, " +
                COLUMN_JENIS + " TEXT, " +
                COLUMN_NOMINAL + " INTEGER)";

        db.execSQL(query);
    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {

        db.execSQL("DROP TABLE IF EXISTS " + TABLE_NAME);
        onCreate(db);
    }

    // MENAMBAHKAN TRANSAKSI
    public boolean tambahTransaksi(String jenis, long nominal) {

        SQLiteDatabase db = this.getWritableDatabase();

        ContentValues values = new ContentValues();
        values.put(COLUMN_JENIS, jenis);
        values.put(COLUMN_NOMINAL, nominal);

        long hasil = db.insert(TABLE_NAME, null, values);

        return hasil != -1;
    }

    // MENAMPILKAN TRANSAKSI
    public Cursor tampilkanTransaksi() {

        SQLiteDatabase db = this.getReadableDatabase();

        return db.rawQuery(
                "SELECT * FROM " + TABLE_NAME +
                        " ORDER BY " + COLUMN_ID + " DESC",
                null
        );
    }

    // MENGHAPUS TRANSAKSI
    public boolean hapusTransaksi(long id) {

        SQLiteDatabase db = this.getWritableDatabase();

        int hasil = db.delete(
                TABLE_NAME,
                COLUMN_ID + " = ?",
                new String[]{String.valueOf(id)}
        );

        return hasil > 0;
    }
}