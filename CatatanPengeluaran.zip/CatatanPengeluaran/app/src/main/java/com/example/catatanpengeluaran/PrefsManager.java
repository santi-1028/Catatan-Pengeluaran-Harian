
        package com.example.catatanpengeluaran;

import android.content.Context;
import android.content.SharedPreferences;

public class PrefsManager {

    private static final String PREF_NAME = "CatatanPengeluaranPrefs";

    private static final String KEY_NAMA = "nama_pengguna";
    private static final String KEY_ANGGARAN = "batas_anggaran";

    private SharedPreferences preferences;

    public PrefsManager(Context context) {

        preferences = context.getSharedPreferences(
                PREF_NAME,
                Context.MODE_PRIVATE
        );
    }

    // MENYIMPAN NAMA PENGGUNA
    public void simpanNama(String nama) {

        preferences.edit()
                .putString(KEY_NAMA, nama)
                .apply();
    }

    // MENGAMBIL NAMA PENGGUNA
    public String ambilNama() {

        return preferences.getString(KEY_NAMA, "");
    }

    // MENYIMPAN BATAS ANGGARAN
    public void simpanAnggaran(long anggaran) {

        preferences.edit()
                .putLong(KEY_ANGGARAN, anggaran)
                .apply();
    }

    // MENGAMBIL BATAS ANGGARAN
    public long ambilAnggaran() {

        return preferences.getLong(KEY_ANGGARAN, 0);
    }

}
