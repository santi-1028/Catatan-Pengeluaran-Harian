
        package com.example.catatanpengeluaran;

import android.os.Bundle;
import android.widget.Button;
import android.widget.TextView;
import android.widget.EditText;
import android.widget.Toast;
import android.database.Cursor;
import android.text.InputType;

import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;

import java.text.NumberFormat;
import java.util.Locale;

public class MainActivity extends AppCompatActivity {

    TextView tvSaldo, tvPemasukan, tvPengeluaran, tvRiwayat;
    Button btnTambah;

    DatabaseHelper databaseHelper;

    long pemasukan = 0;
    long pengeluaran = 0;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        tvSaldo = findViewById(R.id.tvSaldo);
        tvPemasukan = findViewById(R.id.tvPemasukan);
        tvPengeluaran = findViewById(R.id.tvPengeluaran);
        tvRiwayat = findViewById(R.id.tvRiwayat);
        btnTambah = findViewById(R.id.btnTambah);

        databaseHelper = new DatabaseHelper(this);

        tampilkanData();

        btnTambah.setOnClickListener(v -> pilihJenisTransaksi());

        tvRiwayat.setOnClickListener(v -> pilihTransaksiHapus());
    }

    // MEMILIH PEMASUKAN ATAU PENGELUARAN
    private void pilihJenisTransaksi() {

        String[] jenis = {"Pemasukan", "Pengeluaran"};

        new AlertDialog.Builder(this)
                .setTitle("Pilih Jenis Transaksi")
                .setItems(jenis, (dialog, pilihan) -> {
                    tampilkanInputNominal(jenis[pilihan]);
                })
                .setNegativeButton("Batal", null)
                .show();
    }

    // INPUT NOMINAL TRANSAKSI
    private void tampilkanInputNominal(String jenis) {

        EditText input = new EditText(this);

        input.setHint("Contoh: 10000");
        input.setInputType(InputType.TYPE_CLASS_NUMBER);

        new AlertDialog.Builder(this)
                .setTitle(jenis)
                .setMessage("Masukkan nominal uang (Rp)")
                .setView(input)
                .setPositiveButton("Simpan", (dialog, which) -> {

                    String nilai = input.getText().toString().trim();

                    if (nilai.isEmpty()) {
                        Toast.makeText(this,
                                "Nominal belum diisi",
                                Toast.LENGTH_SHORT).show();
                        return;
                    }

                    try {

                        long nominal = Long.parseLong(nilai);

                        if (nominal <= 0) {
                            Toast.makeText(this,
                                    "Nominal harus lebih dari nol",
                                    Toast.LENGTH_SHORT).show();
                            return;
                        }

                        boolean berhasil =
                                databaseHelper.tambahTransaksi(jenis, nominal);

                        if (berhasil) {

                            tampilkanData();

                            Toast.makeText(this,
                                    "Transaksi berhasil disimpan",
                                    Toast.LENGTH_SHORT).show();

                        } else {

                            Toast.makeText(this,
                                    "Transaksi gagal disimpan",
                                    Toast.LENGTH_SHORT).show();
                        }

                    } catch (NumberFormatException e) {

                        Toast.makeText(this,
                                "Nominal tidak valid",
                                Toast.LENGTH_SHORT).show();
                    }
                })
                .setNegativeButton("Batal", null)
                .show();
    }

    // MENAMPILKAN DATA DAN MENGHITUNG SALDO
    private void tampilkanData() {

        pemasukan = 0;
        pengeluaran = 0;

        StringBuilder riwayat = new StringBuilder();

        Cursor cursor = databaseHelper.tampilkanTransaksi();

        if (cursor != null) {

            while (cursor.moveToNext()) {

                String jenis = cursor.getString(
                        cursor.getColumnIndexOrThrow("jenis"));

                long nominal = cursor.getLong(
                        cursor.getColumnIndexOrThrow("nominal"));

                if (jenis.equals("Pemasukan")) {
                    pemasukan += nominal;
                } else {
                    pengeluaran += nominal;
                }

                if (riwayat.length() > 0) {
                    riwayat.append("\n\n");
                }

                riwayat.append(jenis)
                        .append(" : ")
                        .append(formatRupiah(nominal));
            }

            cursor.close();
        }

        long saldo = pemasukan - pengeluaran;

        tvSaldo.setText(formatRupiah(saldo));
        tvPemasukan.setText(formatRupiah(pemasukan));
        tvPengeluaran.setText(formatRupiah(pengeluaran));

        if (riwayat.length() == 0) {
            tvRiwayat.setText("Belum ada transaksi");
        } else {
            tvRiwayat.setText(riwayat.toString());
        }
    }

    // MEMILIH TRANSAKSI YANG AKAN DIHAPUS
    private void pilihTransaksiHapus() {

        Cursor cursor = databaseHelper.tampilkanTransaksi();

        if (cursor == null || cursor.getCount() == 0) {

            Toast.makeText(this,
                    "Belum ada transaksi",
                    Toast.LENGTH_SHORT).show();

            if (cursor != null) {
                cursor.close();
            }

            return;
        }

        String[] daftarTransaksi = new String[cursor.getCount()];
        long[] daftarId = new long[cursor.getCount()];

        int i = 0;

        while (cursor.moveToNext()) {

            daftarId[i] = cursor.getLong(
                    cursor.getColumnIndexOrThrow("id"));

            String jenis = cursor.getString(
                    cursor.getColumnIndexOrThrow("jenis"));

            long nominal = cursor.getLong(
                    cursor.getColumnIndexOrThrow("nominal"));

            daftarTransaksi[i] =
                    jenis + " - " + formatRupiah(nominal);

            i++;
        }

        cursor.close();

        new AlertDialog.Builder(this)
                .setTitle("Pilih Transaksi yang Dihapus")
                .setItems(daftarTransaksi, (dialog, pilihan) -> {

                    konfirmasiHapus(daftarId[pilihan]);

                })
                .setNegativeButton("Batal", null)
                .show();
    }

    // KONFIRMASI HAPUS TRANSAKSI
    private void konfirmasiHapus(long id) {

        new AlertDialog.Builder(this)
                .setTitle("Hapus Transaksi")
                .setMessage("Apakah kamu yakin ingin menghapus transaksi ini?")
                .setPositiveButton("Hapus", (dialog, which) -> {

                    boolean berhasil =
                            databaseHelper.hapusTransaksi(id);

                    if (berhasil) {

                        tampilkanData();

                        Toast.makeText(this,
                                "Transaksi berhasil dihapus",
                                Toast.LENGTH_SHORT).show();

                    } else {

                        Toast.makeText(this,
                                "Transaksi gagal dihapus",
                                Toast.LENGTH_SHORT).show();
                    }
                })
                .setNegativeButton("Batal", null)
                .show();
    }

    // FORMAT RUPIAH
    private String formatRupiah(long angka) {

        NumberFormat format =
                NumberFormat.getCurrencyInstance(
                        new Locale("in", "ID"));

        return format.format(angka);
    }
}